﻿var index = (function (win) {

    // TODO: change this to be your AI name (e.g. Dumbot, Randombot)
    var aiName = "Dibbsabot",
        ai = null;

    function _fireShot() {
        var elem = document.getElementById("shots"),
            move;

        if (!ai) {
            alert('You must first setup the board');
            return;
        }

        // TODO: adjust second array for opponents moves if desired
        move = ai.fire(global.moves, []);

        elem.innerHTML += "<br />" + move.toString();
    }

    function _setupBoard() {
        var elem = document.getElementById("board"),
            board, 
            len, 
            i = -1;

        ai = new win[aiName]();
        board = ai.setupBoard([2, 3, 3, 4, 5]);

        elem.innerHTML = "";
        for (len = board.length; ++i < len;) {
            elem.innerHTML += "<br />";
            elem.innerHTML += board[i].toString() + " - Length: " + board[i].getLength();
        }
    }

    function onLoad() {
        document.getElementById("setupBoard").addEventListener("click", _setupBoard);
        document.getElementById("fireShot").addEventListener("click", _fireShot);
    }

    return {
        onLoad: onLoad
    };
})(this), global = {};